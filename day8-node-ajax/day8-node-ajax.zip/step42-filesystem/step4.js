const fetch = require("fetch");
const fs = require("fs");


fetch.fetchUrl("https://www.ibm.com/in-en", function(error, meta, data){
   /*  
   if(error){
        console.log("Error ", error);
    }else{
        console.log("Meta ", meta);
        console.log(data.toString());
    } 
    */


    if(error){
        console.log("Error ", error);
    }else{
        console.log("Meta ", meta);
        fs.writeFileSync("temp.html",data.toString(),"utf-8");
    } 

});
