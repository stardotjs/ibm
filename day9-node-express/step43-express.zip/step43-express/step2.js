const express = require("express");
let app = express();
// Routes
app.get("/", function(req, res){
    res.sendFile(__dirname+"/index.html");
});
app.get("/about", function(req, res){
    res.sendFile(__dirname+"/about.html");
});
app.get("/contact", function(req, res){
    res.sendFile(__dirname+"/contact.html");
});

app.listen(1010,"localhost",function(error){
    if(error){
        console.log("Error ", error);
    }else{
        console.log("Web server is now live on localhost:1010");
    }
});