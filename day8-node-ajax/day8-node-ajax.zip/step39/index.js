let hero = {
    title : "Batman"
};

module.exports = hero;