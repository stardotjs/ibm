const express = require("express");
let app = express();
// Routes
app.get("/", function(req, res){
    /*
    res.write("hello from express");
    res.end();
    */
    /*
    res.end("hello from express");
    */
    // res.send("hello from express");
    res.sendFile(__dirname+"/index.html");
    // res.json();
    // res.sendFile();
    // res.render();
});

app.listen(1010,"localhost",function(error){
    if(error){
        console.log("Error ", error);
    }else{
        console.log("Web server is now live on localhost:1010");
    }
});