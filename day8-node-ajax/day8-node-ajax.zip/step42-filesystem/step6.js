const axios = require("axios");
const fs = require("fs");
const zlib = require("zlib");

axios({
    method : "get",
    url : "https://www.ibm.com/in-en",
    responseType : "stream"
})
.then( res => {
    console.log(res.data)
    return res;
})
.then( res => 
    res.data.pipe( zlib.createGzip() )
    .pipe( fs.createWriteStream("ibmpage.html.zip")) );

