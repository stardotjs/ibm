const http = require("http");
const fs = require("fs");

let server = http.createServer(function(req, res){
    console.log("Req ", req.url);
    // text/plain
    // text/html
    // application/json
    res.writeHead(200,{
        "Content-Type" : "text/html"
    });

    // res.write(JSON.stringify( { "title" : "Batman" } ));
    res.write(fs.readFileSync("index.html","utf-8"));
    res.end();
});

server.listen(1010, "localhost", function(error){
    if(error){ console.log("Error ", error)}
    else{ console.log("Server is now live on localhost:1010")}
});
