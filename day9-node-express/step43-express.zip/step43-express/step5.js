const express = require("express");
let app = express();
let data = require("./data/data.json");
// configuration
app.use(express.static(__dirname+"/public"));

app.get("/data", (req, res)=> res.json(data))

app.listen(1010);
console.log("Web server is now live on localhost:1010");