const express = require("express");
let app = express();
app.use(express.urlencoded({extended : true}));
let heroes = [];
app.get("/", (req, res)=>{
   res.render("home.pug", {
    company : "IBM Bangalore",
    heroes
   });
   // res.render("home.pug");
   // res.render("home.jade");
})
app.post("/",(req, res)=>{
    // console.log(req.body.hname);
    heroes.push(req.body.hname);
    res.redirect("/");
})
app.listen(1010);
console.log("Web server is now live on localhost:1010");