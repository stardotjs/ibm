const express = require("express");
const Hero = require("./hero.model");
const errorHandler = require("./utils");

let routes = express.Router();
// READ
routes.get("/data",(req, res)=>{
    Hero.find((error, dbres)=>{
        if(error){
            errorHandler(error);
        }else{
            res.json(dbres);
        }
    })
})
// CREATE
routes.post("/data",(req, res)=>{
    let hero = new Hero(req.body);
    hero.save()
    .then(dbres=>res.json({ message : "Hero is now added", dbres }))
    .catch(error => errorHandler(error));
})
// SELECT TO UPDATE
routes.get("/edit/:id", (req, res)=>{
    Hero.findById({_id : req.params.id },(error, editInfo)=>{
        if(error){ errorHandler(error)}
        else{ res.json( editInfo )}
    } )
});
routes.post("/edit/:id", (req, res)=>{
    Hero.findById({_id : req.params.id},(error, editInfo)=>{
        if(error){ errorHandler(error)}
        else{ 
            editInfo.title = req.body.title;
            editInfo.name =  req.body.name;
            editInfo.city =  req.body.city;
            editInfo.power = req.body.power;            
            editInfo.save()
            .then(updateRes => res.json({message : "Hero is updated"}))
            .catch(error => errorHandler(error))
        }
    } )
});

routes.delete("/delete/:id", (req, res)=>{
    Hero.findByIdAndDelete({_id : req.params.id },(error, deletedInfo)=>{
        if(error){ errorHandler(error)}
        else{ res.json({message : deletedInfo.title+" was deleted " })};
    } )
});

module.exports = routes;