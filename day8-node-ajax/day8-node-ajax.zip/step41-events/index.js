const EventEmitter = require("events").EventEmitter;

let myevent = new EventEmitter();

function ibmHandler(){
    console.log("IBM event happened");
};

myevent.on("ibm", ibmHandler);

setInterval(function(){
    myevent.emit("ibm");
},1000);

setTimeout(function(){
    myevent.off("ibm", ibmHandler);
},10000)
