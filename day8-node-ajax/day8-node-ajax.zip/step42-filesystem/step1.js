// const fs = require("fs");

/* 
fs.writeFileSync("temp.txt","welcome to your life","utf-8");
console.log("the file is now ready"); 
*/

/* 
fs.writeFile("temp.txt","welcome to your life !!!", "utf-8",function(error){
    if(error){
        console.log("Error ", error);
    }else{
        console.log("File is now ready");
    }
});
*/

// let data = fs.readFileSync("temp.txt","utf-8");
// console.log(data.toString());
// console.log(data+"");
// console.log(data);

/* 
fs.readFile("temp.txt","utf-8",function(error, data){
    if(error){ console.log("Error ", error )}
    else{ console.log("log from line 25 ",data)}
});
console.log("log from line 27"); 
*/