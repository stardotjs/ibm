/* 
let hero = require("./../step39/index");

console.log(hero.title); 
*/

/* 
const os = require('os');
console.log("Architecture", os.arch());
console.log("Number of CPUs", os.cpus().length);
console.log("Total Memory", os.totalmem(),"bytes", ((os.totalmem() / 1024)/1024) / 1024 , "GB");
console.log("Free Memory", os.freemem(),"bytes", ((os.freemem() / 1024)/1024) / 1024, "GB");
console.log(os.userInfo().username);
 */

// console.log(process.argv);
let username = process.argv[2];
let usercity = process.argv[3];
console.log(username.toUpperCase(), "is from ", usercity);