const axios = require("axios");
const fs = require("fs");

axios({
    method : "get",
    url : "https://www.ibm.com/in-en",
    responseType : "stream"
})
.then( res => {
    console.log(res.data)
    return res;
})
.then( res => res.data.pipe( fs.createWriteStream("axios.html") ) );

