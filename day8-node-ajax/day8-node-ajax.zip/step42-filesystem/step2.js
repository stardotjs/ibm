const fs = require("fs");
/* 
fs.mkdirSync("data");
fs.access("datas", function(error){
    if(error){ console.log("Error ", error.message)}
    else{
        console.log("folder exists")
    }
})
*/
fs.mkdirSync("data");
// fs.writeFileSync("data/temp.txt","Welcome to your life, there's no turning back","utf-8");
fs.access("data", function(error){
    if(error){ console.log("Error ", error.message)}
    else{
        console.log("folder exists");
        process.chdir("data");
        fs.writeFileSync("temp.txt","Welcome to your life, there's no turning back","utf-8");
        let file = fs.statSync("temp.txt");
        console.log("Size ",file.size, "Creation time ", file.birthtime);
        // fs.renameSync("temp.txt","song.txt");
    }
})



