let errorHandler = (error)=> console.log("Error ",error);
module.exports = errorHandler;