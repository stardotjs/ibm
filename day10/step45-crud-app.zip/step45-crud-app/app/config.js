module.exports = {
    port : 2525,
    host : "localhost",
    dbname : "ibmdb",
    dbuser : "admin",
    dbpass : "RgfdOdCuADM2Rk2j",
    dburl : "mongodb+srv://<username>:<password>@cluster0.clwkjok.mongodb.net/<dbname>?retryWrites=true&w=majority"
}
