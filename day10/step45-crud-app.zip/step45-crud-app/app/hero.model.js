const mongoose = require("mongoose");

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

let Hero = mongoose.model("Hero", new Schema({
    id : ObjectId,
    title : String,
    name : String,
    city : String,
    power : Number
}));

module.exports = Hero;