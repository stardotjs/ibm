const express = require("express");
const mongoose = require("mongoose");
// const cors = require("cors");
let config = require("./app/config");
let errorHandler = require("./app/utils");
const HeroModel = require("./app/hero.model");
const routes = require("./app/hero.routes");
// database configuration
//-----------------------------------
let url = config.dburl.replace("<username>", config.dbuser)
                      .replace("<password>",config.dbpass)
                      .replace("<dbname>",config.dbname);
mongoose.connect(url).then(res=>console.log("DB Connected")).catch(error => errorHandler(error))
// express middlewares
//-----------------------------------
let app = express();
app
.use(express.static(__dirname+"/public"))
.use(express.json())
.use(routes);
// webserver configuration
//-----------------------------------
app.listen(config.port, config.host,(error)=>{
    if(error){
        errorHandler(error)
    }else{
        console.log("web server is live on "+config.host+":"+config.port);
    }
});
