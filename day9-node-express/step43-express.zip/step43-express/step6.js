const express = require("express");
let app = express();
let fs = require("fs");


// middleware
let appdata = JSON.parse( fs.readFileSync("data/data.json","utf-8") );
app.use(express.static(__dirname+"/public"));
app.use(express.json());

// routes
app.get("/data", (req, res)=> res.json(appdata))
app.post("/data", ( req, res )=>{
    // console.log(req.body.nhero);
    appdata.heroes.push(req.body.nhero);
    res.send({message : "hero recieved"});
    fs.writeFileSync("data/data.json",JSON.stringify(appdata));
})

app.listen(1010);
console.log("Web server is now live on localhost:1010");